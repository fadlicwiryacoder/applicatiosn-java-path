#import <Foundation/Foundation.h>

NSString* foo(void);