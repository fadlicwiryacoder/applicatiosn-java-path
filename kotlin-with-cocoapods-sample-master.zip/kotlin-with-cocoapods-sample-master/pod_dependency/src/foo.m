#include "foo.h"

NSString* foo() {
    return @"Foo";
}