import cocoapods.pod_dependency.*
import cocoapods.SDWebImage.*
import cocoapods.AFNetworking.*
import cocoapods.subspec_dependency.*

fun bar() {
    println(AFNetworkingReachabilityNotificationStatusItem)
    println(foo())
}

fun bazz() {
    println(SDGraphicsImageRendererFormatRangeAutomatic)
    println(baz())
}