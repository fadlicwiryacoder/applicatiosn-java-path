#import <Foundation/Foundation.h>

NSString* baz(void);