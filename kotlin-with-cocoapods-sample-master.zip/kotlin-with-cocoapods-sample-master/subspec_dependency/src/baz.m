#include "baz.h"

NSString* baz() {
    return @"Baz";
}